
import java.util.*;

/**
 * 
 */
public class Circle implements Shape {

    /**
     * Default constructor
     */
    public Circle() {
    }

    /**
     * @return
     */
    public void draw() {
 System.out.println("Shape: Circle");
        // TODO implement here
        
    }

}
