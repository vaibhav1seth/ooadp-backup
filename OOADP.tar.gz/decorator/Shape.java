
import java.util.*;

public interface Shape {
 void draw();
}
