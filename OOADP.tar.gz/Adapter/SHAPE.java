
import java.util.*;

/**
 * 
 */
public abstract class SHAPE {

    /**
     * Default constructor
     */
    public SHAPE() {
    }

    /**
     * 
     */
    public void setlocation() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getLocation() {
        // TODO implement here
    }

    /**
     * 
     */
    public abstract void display();

    /**
     * 
     */
    public abstract void full();

    /**
     * 
     */
    public void setcolor() {
        // TODO implement here
    }

    /**
     * 
     */
    public abstract void undisplay();

}