
import java.util.*;

/**
 * 
 */
public class CIRCLE extends SHAPE {

    /**
     * Default constructor
     */
    public CIRCLE() {
    }


    /**
     * 
     */
    public void setLocation() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getLocation() {
        // TODO implement here
    }

    /**
     * 
     */
    public void display() {
        // TODO implement here
    }

    /**
     * 
     */
    public void full() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setcolor() {
        // TODO implement here
    }

    /**
     * 
     */
    public void undisplay() {
        // TODO implement here
    }

    /**
     * 
     */
    public abstract void display();

    /**
     * 
     */
    public abstract void full();

    /**
     * 
     */
    public abstract void undisplay();

}