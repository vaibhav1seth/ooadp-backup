
import java.util.*;

/**
 * 
 */
public class LINE extends SHAPE {

    /**
     * Default constructor
     */
    public LINE() {
    }

    /**
     * 
     */
    public void display() {
        // TODO implement here
    }

    /**
     * 
     */
    public void full() {
        // TODO implement here
    }

    /**
     * 
     */
    public void undisplay() {
        // TODO implement here
    }

    /**
     * 
     */
    public abstract void display();

    /**
     * 
     */
    public abstract void full();

    /**
     * 
     */
    public abstract void undisplay();

}