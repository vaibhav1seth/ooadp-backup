
import java.util.*;

/**
 * 
 */
public class Client Adapter {

    /**
     * Default constructor
     */
    public Client Adapter() {
    }

}