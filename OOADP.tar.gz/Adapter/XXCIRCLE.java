
import java.util.*;

/**
 * 
 */
public class XXCIRCLE {

    /**
     * Default constructor
     */
    public XXCIRCLE() {
    }


    /**
     * 
     */
    public void setLocation() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getLocation() {
        // TODO implement here
    }

    /**
     * 
     */
    public void display() {
        // TODO implement here
    }

    /**
     * 
     */
    public void full() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setcolor() {
        // TODO implement here
    }

    /**
     * 
     */
    public void undisplay() {
        // TODO implement here
    }

}