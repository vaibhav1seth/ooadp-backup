import java.util.*;

/**
 * 
 */
public interface Color {
   void fill();
}

