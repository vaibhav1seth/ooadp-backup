
import java.util.*;

/**
 * 
 */
public class SalesOrder {

    /**
     * Default constructor
     */
    public SalesOrder() {
    }


    /**
     * 
     */
    public void calcTax() {
        // TODO implement here
    }

}