
import java.util.*;

/**
 * 
 */
public class CalcTax {

    /**
     * Default constructor
     */
    public CalcTax() {
    }


    /**
     * @param itemSold 
     * @param qty 
     * @param price 
     * @return
     */
    public double taxAmount(Salable itemSold, double qty, double price) {
        // TODO implement here
        return 0.0d;
    }

}