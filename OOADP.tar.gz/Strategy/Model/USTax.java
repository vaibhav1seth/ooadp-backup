
import java.util.*;

/**
 * 
 */
public class USTax extends CalcTax {

    /**
     * Default constructor
     */
    public USTax() {
    }

}