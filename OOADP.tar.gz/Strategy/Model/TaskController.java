
import java.util.*;

/**
 * 
 */
public class TaskController {

    /**
     * Default constructor
     */
    public TaskController() {
    }

}