
import java.util.*;

/**
 * 
 */
public class CanTax extends CalcTax {

    /**
     * Default constructor
     */
    public CanTax() {
    }

}