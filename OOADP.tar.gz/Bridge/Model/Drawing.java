
import java.util.*;

/**
 * 
 */
public abstract class Drawing {

    /**
     * Default constructor
     */
    public Drawing() {
    }


    /**
     * 
     */
    public void drawLine() {
        // TODO implement here
    }

}