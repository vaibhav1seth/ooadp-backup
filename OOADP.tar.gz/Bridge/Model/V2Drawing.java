
import java.util.*;

/**
 * 
 */
public class V2Drawing extends Drawing {

    /**
     * Default constructor
     */
    public V2Drawing() {
    }

    /**
     * 
     */
    public void drawLine() {
        // TODO implement here
    }

}