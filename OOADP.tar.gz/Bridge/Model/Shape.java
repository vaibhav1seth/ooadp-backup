
import java.util.*;

/**
 * 
 */
public abstract class Shape {

    /**
     * Default constructor
     */
    public Shape() {
    }


    /**
     * 
     */
    public void draw() {
        // TODO implement here
    }

}