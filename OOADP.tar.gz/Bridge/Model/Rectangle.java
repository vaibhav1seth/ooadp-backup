
import java.util.*;

/**
 * 
 */
public class Rectangle extends Shape {

    /**
     * Default constructor
     */
    public Rectangle() {
    }

    /**
     * 
     */
    public void draw() {
        // TODO implement here
    }

}