
import java.util.*;

/**
 * 
 */
public class V1Drawing extends Drawing {

    /**
     * Default constructor
     */
    public V1Drawing() {
    }

    /**
     * 
     */
    public void drawLine() {
        // TODO implement here
    }

}