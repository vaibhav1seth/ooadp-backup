abstract class Drawing {
	abstract void drawLine(double x1, double y1, double x2, double y2);
}
class V1Drawing extends Drawing {
void drawLine(double x1, double y1, double x2, double y2){
	System.out.println("Line from ("+x1+", "+y1+") to ("+x2+", "+y2+")");
}
}
class V2Drawing extends Drawing{
void drawLine(double x1, double y1, double x2, double y2){
	System.out.println("Line from ("+x1+", "+y1+") to ("+x2+", "+y2+")");
}
}
abstract class Shape{

Drawing drawing;
public Shape(Drawing drawing){
this.drawing = drawing;
}
abstract void draw();
}

class Rectangle extends Shape{
double _x1, _y1, _x2, _y2;
Rectangle(Drawing dp, double x1, double y1, double x2, double y2){
super(dp);
_x1 = x1;
_y1 = y1;
_x2 = x2;
_y2 = y2;

}

public void draw(){
System.out.println("\n I am a Rectangle \n");
drawing.drawLine(_x1, _y1, _x2, _y1);
drawing.drawLine(_x2, _y1, _x2, _y2);
drawing.drawLine(_x2, _y2, _x1, _y2);
drawing.drawLine(_x1, _y2, _x1, _y1);
}

}

class Square extends Shape{
double _x1, _y1, _x2, _y2;
Square(Drawing dp, double x1, double y1, double x2, double y2){
super(dp);
_x1 = x1;
_y1 = y1;
_x2 = x2;
_y2 = y2;

}

public void draw(){
System.out.println("\n I am a Square \n");
drawing.drawLine(_x1, _y1, _x2, _y1);
drawing.drawLine(_x2, _y1, _x2, _y2);
drawing.drawLine(_x2, _y2, _x1, _y2);
drawing.drawLine(_x1, _y2, _x1, _y1);
}
}

public class TestBridge{
public static void main(String[] args) {

Drawing dp1 = new V1Drawing();
Drawing dp2 = new V2Drawing();
Shape rect1 = new Rectangle(dp1, 50, 200, 60, 100);
rect1.draw();
Shape sqr1 = new Square(dp2, 10, 40, 20, 50);
sqr1.draw();
}
}
