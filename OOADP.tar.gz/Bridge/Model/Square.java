
import java.util.*;

/**
 * 
 */
public class Square extends Shape {

    /**
     * Default constructor
     */
    public Square() {
    }

    /**
     * 
     */
    public void draw() {
        // TODO implement here
    }

}