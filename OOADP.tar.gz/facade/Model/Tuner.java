
import java.util.*;

/**
 * 
 */
public class Tuner {

    /**
     * Default constructor
     */
    public Tuner() {
    }

    /**
     * 
     */
    public void amplifier()
{}

    /**
     * 
     */
    public void on() {
        // TODO implement here
    }

    /**
     * 
     */
    public void off() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setAm() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setFm() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setFrequency() {
        // TODO implement here
    }

}
