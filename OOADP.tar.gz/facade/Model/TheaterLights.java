
import java.util.*;

/**
 * 
 */
public class TheaterLights {

    /**
     * Default constructor
     */
    public TheaterLights() {
   System.out.println("Lighting adjusted");
    }

    /**
     * 
     */
    public void on() {
        // TODO implement here
  
    }

    /**
     * 
     */
    public void off() {
        // TODO implement here
System.out.println("Lights off");
 
    }

    /**
     * 
     */
    public void dim() {
        // TODO implement here
  
    }

}
