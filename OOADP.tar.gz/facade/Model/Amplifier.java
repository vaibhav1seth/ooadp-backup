
import java.util.*;

/**
 * 
 */
public class Amplifier {

    /**
     * Default constructor
     */
    public Amplifier() {
    }

    /**
     * 
     */
    public void Tuner()
{}

    /**
     * 
     */
    public void DvdPlayer()
{}

    /**
     * 
     */
    public void CdPlayer()
{}

    /**
     * 
     */
    public void on() {
        // TODO implement here
   System.out.println("Amplifier on and adjusted");
    }

    /**
     * 
     */
    public void off() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setCd() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setDvd() {
        // TODO implement here
   System.out.println("Dvd on");
    }

    /**
     * 
     */
    public void setSterioSound() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setSurroundSound() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setTuner() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setVolume() {
        // TODO implement here
   System.out.println("volume set");
    }

}
