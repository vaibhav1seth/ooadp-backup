
import java.util.*;

/**
 * 
 */
public class CdPlayer {

    /**
     * Default constructor
     */
    public CdPlayer() {
    }

    /**
     * 
     */
    public void amplifier()
{}

    /**
     * 
     */
    public void on() {
        // TODO implement here
    }

    /**
     * 
     */
    public void off() {
        // TODO implement here
    }

    /**
     * 
     */
    public void eject() {
        // TODO implement here
    }

    /**
     * 
     */
    public void pause() {
        // TODO implement here
    }

    /**
     * 
     */
    public void play() {
        // TODO implement here
    }

    /**
     * 
     */
   // public void play() {
        // TODO implement here
    //}

    /**
     * 
     */
    public void stop() {
        // TODO implement here
    }

}
