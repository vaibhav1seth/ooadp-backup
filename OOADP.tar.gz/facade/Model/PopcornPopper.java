
import java.util.*;

/**
 * 
 */
public class PopcornPopper {

    /**
     * Default constructor
     */
    public PopcornPopper() {
    }

    /**
     * 
     */
    public void on() {
        // TODO implement here
   System.out.println("Popping popcorn");
    }

    /**
     * 
     */
    public void off() {
        // TODO implement here
    }

    /**
     * 
     */
    public void pop() {
        // TODO implement here
    }

}
