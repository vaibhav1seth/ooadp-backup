
import java.util.*;

/**
 * 
 */
public class Projector {

    /**
     * Default constructor
     */
    public Projector() {
    }

    /**
     * 
     */
    public void DvdPlayer()
{}

    /**
     * 
     */
    public void on() {
        // TODO implement here
    }

    /**
     * 
     */
    public void off() {
        // TODO implement here
    }

    /**
     * 
     */
    public void tvMode() {
        // TODO implement here
    }

    /**
     * 
     */
    public void wideScreenMode() {
        // TODO implement here
    }

}
