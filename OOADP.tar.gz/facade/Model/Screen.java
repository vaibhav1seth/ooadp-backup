
import java.util.*;

/**
 * 
 */
public class Screen {

    /**
     * Default constructor
     */
    public Screen() {
   System.out.println("Screen set");
    }

    /**
     * 
     */
    public void up() {
        // TODO implement here
    }

    /**
     * 
     */
    public void down() {
        // TODO implement here
    }

}
